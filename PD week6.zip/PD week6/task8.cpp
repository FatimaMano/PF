#include<iostream>
using namespace std;
main()
{
    int coordinatex, coordinatey;
    int h_;
    cout<<"Enter coordinate of x axis";
    cin>>coordinatex;
    cout<<"Enter the coordinate fo y axis";
    cin>>coordinatey;
    cout<<"Enter the value of h";
    cin>>h_;
    int x_range = 2 * h_;
    int y_range = 4 * h_;
    if((0 < coordinatex < h_) && (h_<coordinatey<3*h_) ||((h_<coordinatex<x_range && 0<coordinatey<y_range)))
    {
        cout<<"Inside";
    } 
    else if((coordinatex < 0 || coordinatex > x_range) || (coordinatey < 0 || coordinatey > y_range))
    {
        cout<<"Outside";
    }
    else
    {
        cout<<"Border";
    }

}